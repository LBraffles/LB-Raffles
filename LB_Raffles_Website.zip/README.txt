LB RAFFLES WEBSITE
===================

This is the first customer-facing website build.

Included:
- Responsive LB Raffles landing page
- Competition section
- 100-number selector
- Sold/available/selected states
- £15 price calculation
- Mobile layout
- How-it-works section
- Compliance notice

NOT YET LIVE:
- Database / server-side reservations
- Real customer accounts
- Payment processing
- Webhooks
- Admin dashboard
- Email confirmations

Those need to be connected before accepting real entries. In particular, do not treat a simple paid random draw as legally cleared: UK Gambling Commission guidance distinguishes lotteries from compliant free draws and genuine prize competitions.
