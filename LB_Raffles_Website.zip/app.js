const sold = new Set([3,8,14,22,31,47,58,66,73,91]);
const selected = new Set();
const numbers = document.getElementById('numbers');
for(let i=1;i<=100;i++){
  const b=document.createElement('button');
  b.className='num'+(sold.has(i)?' sold':'');
  b.textContent=String(i).padStart(3,'0');
  b.disabled=sold.has(i);
  if(!b.disabled)b.onclick=()=>{selected.has(i)?selected.delete(i):selected.add(i);b.classList.toggle('selected');update()};
  numbers.appendChild(b);
}
function update(){
 document.getElementById('selectedCount').textContent=selected.size;
 document.getElementById('total').textContent=selected.size*15;
 document.getElementById('continue').disabled=selected.size===0;
}
document.getElementById('continue').onclick=()=>alert('Checkout is the next integration step. Selected: '+[...selected].sort((a,b)=>a-b).map(n=>String(n).padStart(3,'0')).join(', '));
document.getElementById('soldCount').textContent=sold.size;
document.getElementById('progress').style.width=(sold.size)+'%';
